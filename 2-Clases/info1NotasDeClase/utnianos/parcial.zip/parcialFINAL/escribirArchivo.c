#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CLEAR "clear"

/*Struct*/

struct id
{
	char nombre[20];
	char direccion [20];
	char profesion[20];
};

/*Main*/

int main (void)

{
	int opcion=1;
	struct id datos;
	char archivo [30];
	
	FILE*f;
	
	system(CLEAR);
	printf("Escribir nombre del archivo a escribir/crear: ");
	scanf(" %[^\n]s", archivo);
	
		if ((f=fopen(archivo,"w"))==NULL)
		{
		printf("\nError al abrir el archivo\n");
		return 0;
		}
	
		system (CLEAR);
		printf("Ingresar: ");
		printf("\n1 para ingresar una persona o cualquier numero para salir: ");
		scanf("%d", &opcion);
		
		while(opcion==1)
		{
		
			system(CLEAR);
			printf("Ingresar el nombre de la persona: ");
			scanf(" %[^\n]s", datos.nombre);
			printf("\nIngresar direccion: ");
			scanf(" %[^\n]s", datos.direccion);
			printf("\nIngresar profesion: ");
			scanf(" %[^\n]s", datos.profesion);
			fwrite(&datos, sizeof(struct id), 1, f);
			printf("\n1 para ingresar una persona o cualquier numero para salir: ");
			scanf("%d", &opcion);
		}
	
	fclose(f);
	return 0;
}
