#include <stdio.h>
#include <stdlib.h>
#define CLEAR "clear"

/*Structs*/

struct rank
{
	char nombre[20];
	char direccion [20];
	char profesion [20];
	int intervencion;
};

/*main*/

int main (void)
{
	FILE* f;
	struct rank datos;
	
	system(CLEAR);
	
	if ((f=fopen("ranking", "r"))==NULL)
	{
		printf("\nError al abrir el archivo ranking\n");
	}
	
	else
	{
		fread(&datos, sizeof(struct rank), 1 , f);
		
		while(feof(f)==0)
		{
			
			
			printf("\n\nPersona: %s\n", datos.nombre);
			printf("Direccion: %s\n", datos.direccion);
			printf("Profesion: %s\n", datos.profesion);
			printf("Ocurrencias o intervenciones: %d\n", datos.intervencion);
			fread(&datos, sizeof(struct rank), 1 , f);
			
		}
		
		fclose(f);
	}
	
	return 0;
	
}
