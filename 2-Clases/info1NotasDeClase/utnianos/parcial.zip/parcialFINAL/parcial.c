#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*Estructuras*/

struct ranking
{
	char nombre[20];
	char direccion [20];
	char profesion [20];
	int intervencion;
};

struct id
{
	char nombre[20];
	char direccion [20];
	char profesion[20];
};

struct participante
{
	struct ranking datos;
	struct participante *next;
	
};

/*Prototipos de funciones*/

void agregarNodo(struct participante**, struct id);
void cargarDatos(struct participante**, struct id);
void escribirArchivo(struct participante**);
void eliminarLista (struct participante**);

/*Main*/

int main (int argc, char*argv[])
{
	FILE*f;
	struct participante *inicio;
	int i=0;
	struct id datos;	
	inicio=NULL;
	for (i=1;i<argc;i++)
	{	
		if ((f=fopen(argv[i], "r"))==NULL)
		{	
			printf("\n Error al abrir el archivo %s\n",*(argv+i));
		}
		else
		{	
			fread(&datos , sizeof(struct id), 1 , f);
			while(feof(f)==0)
			{	

				agregarNodo (&inicio, datos);
				fread(&datos , sizeof(struct id), 1 , f);
				
			}
			
			fclose(f);
			
		}
		
	}
	
	escribirArchivo(&inicio);
	eliminarLista(&inicio);	
	
	return 0;
	
}

/*Funciones*/

void agregarNodo(struct participante**inicio, struct id datos)
{
	struct participante *aux;
	struct participante *ant;
	struct participante *act;
	
	aux = (struct participante*)malloc(sizeof(struct participante));
	ant = act = *inicio;
	
	cargarDatos(&aux, datos);
	
	if (aux==NULL)
	{
		printf("\nERROR, No se pudo agregar un nuevo nodo a la lista\n");
		return;
	}
	
	else
	{
		aux->next = NULL;
		
		if(*inicio==NULL)												/*lista vacia*/
		{
			aux->next=NULL;
			*inicio=aux;
			return;
		}
		
		
		
		while(act!=NULL && strcmp(act->datos.nombre,aux->datos.nombre) <=0)
		{
			if(strcmp(act->datos.nombre,aux->datos.nombre) ==0){
				
				act->datos.intervencion=act->datos.intervencion+1;
				return;
			}
			ant = act;
			act = act->next;
			
		}
		
		if(act==NULL)													/*Final lista*/
		{
			ant->next=aux;
			aux->next=NULL;
			return;
		}

		if(ant==act)													/*Inicio de lista*/
		{
			*inicio=aux;
			aux->next=ant;
			return;
		}
		
		ant->next=aux;
		aux->next=act;
		return;
	}
	
	
	
	
}

void cargarDatos(struct participante **aux, struct id datos)
{
	strcpy((*aux)->datos.nombre, datos.nombre);
	strcpy((*aux)->datos.direccion, datos.direccion);
	strcpy((*aux)->datos.profesion, datos.profesion);
	(*aux)->datos.intervencion=1;
	
}

void escribirArchivo (struct participante **inicio)
{	
	FILE*f;
	struct participante *auxiliar;
	auxiliar=*inicio;
	
	if ((f=fopen("ranking","w"))==NULL)
	{
		printf("\nError al escribir el archivo ranking\n");
	}
	
	else
	{
		while(auxiliar!=NULL)
		{

			fwrite(&auxiliar->datos, sizeof(struct ranking),1,f);
			auxiliar=auxiliar->next;
		}
		
	}fclose(f);
}

void eliminarLista(struct participante **inicio)
{
	struct participante*ant;
	struct participante*act;
	
	ant=act=*inicio;
	
	while(act!=NULL)
	{
		ant=act;
		act=act->next;
		free(ant);
	}
}
